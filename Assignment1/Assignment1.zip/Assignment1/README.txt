Assignment 1 
CMPUT 379 Fall 2020

NAME: Cyrus Diego
CCID: cdiego

HOW-TO-RUN:
- in project directory, run "make" 
- run "./shell379"

- use "make clean" to erase .o and executable

Files Included:
- Makefile
- main.cpp
- shell.cpp
- shell.hpp
- parser.cpp
- parser.hpp
- helpers.cpp
- helpers.hpp
- constants.hpp
