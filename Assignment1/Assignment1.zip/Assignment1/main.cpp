#include "shell.hpp"

int main() {
  // instantiate shell379 class and run main loop
  Shell shell379;
  shell379.run();

  return 0;
}